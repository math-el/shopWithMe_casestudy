﻿using maviTest.Application.Dto;
using maviTest.Application.Interfaces.Repository;
using maviTest.Domain.Entities;
using maviTest.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Persistence.Repositories
{
    internal class PriceRepository : GenericRepository<PriceEntity>, IPriceRepository
    {

        public PriceRepository(ApplicationDbContext dbContext) : base(dbContext)
        {


        }
        private static List<PriceEntity> priceList = new List<PriceEntity>()
                {
                    new PriceEntity(){ ProductId = 1, PriceAmount= 5, BeginDate= DateTime.Now.AddDays(-10)},
                    new PriceEntity(){ ProductId = 2, PriceAmount= 15, BeginDate= DateTime.Now.AddDays(-10)},
                    new PriceEntity(){ ProductId = 3, PriceAmount= 25, BeginDate= DateTime.Now.AddDays(-10)},
                    new PriceEntity(){ ProductId = 4, PriceAmount= 35, BeginDate= DateTime.Now.AddDays(-10)},
                    new PriceEntity(){ ProductId = 5, PriceAmount= 45, BeginDate= DateTime.Now.AddDays(-10)},
                    new PriceEntity(){ ProductId = 6, PriceAmount= 55, BeginDate= DateTime.Now.AddDays(-10)}
                };
        public async Task<List<PriceEntity>> GetPricesByIdList(List<int> IdList)
        {
            return priceList.FindAll(p => IdList.Contains(p.ProductId));
        }
    }
}
