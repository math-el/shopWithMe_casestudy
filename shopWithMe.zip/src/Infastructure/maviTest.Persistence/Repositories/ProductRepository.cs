﻿using maviTest.Application.Dto;
using maviTest.Application.Interfaces.Repository;
using maviTest.Domain.Entities;
using maviTest.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Persistence.Repositories
{
    internal class ProductRepository : GenericRepository<ProductEntity>, IProductRepository
    {
       
        public ProductRepository(ApplicationDbContext dbContext) : base(dbContext)
        {


        }
        public static List<ProductEntity> productViewDtoList = new List<ProductEntity>()
                {
                    new ProductEntity { Id= 1, ProductName= "T-shirt", CategoryId=1 },
                    new ProductEntity { Id=2, ProductName="Pants", CategoryId = 1 },
                    new ProductEntity { Id = 3, ProductName = "Eyeshadow", CategoryId = 2 },
                    new ProductEntity { Id = 4, ProductName = "Blush", CategoryId = 2 },
                    new ProductEntity { Id = 5, ProductName = "Cucumber", CategoryId = 3 },
                    new ProductEntity { Id = 6, ProductName = "Tomatoes", CategoryId = 3 }
                };
        public async Task<List<ProductEntity>> GetProductByIdList(List<int> IdList)
        {
            return productViewDtoList.FindAll(p => IdList.Contains(p.Id));
        }
    }
}
