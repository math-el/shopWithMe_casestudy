﻿using maviTest.Application.Dto;
using maviTest.Application.Interfaces.Repository;
using maviTest.Domain.Entities;
using maviTest.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Persistence.Repositories
{
    internal class PromotionRepository : GenericRepository<PromotionEntity>, IPromotionRepository
    {

        public PromotionRepository(ApplicationDbContext dbContext) : base(dbContext)
        {


        }
        private static List<PromotionEntity> promotionList = new List<PromotionEntity>() {
         new PromotionEntity(){ PromotionId=1, DiscountAmount=30, PromotionPriceType= 2, PromotionType= 0, PerAmount=0, PromotionUserType= 2, UserYear=0 },
         new PromotionEntity(){ PromotionId=2, DiscountAmount=10, PromotionPriceType= 2, PromotionType=0, PerAmount=0, PromotionUserType= 1 , UserYear=0 },
         new PromotionEntity(){ PromotionId=3, DiscountAmount=5, PromotionPriceType= 2, PromotionType= 0, PerAmount=0, PromotionUserType= 3 , UserYear=2 },
         new PromotionEntity(){ PromotionId=4, DiscountAmount=5, PromotionPriceType= 1, PromotionType= 1, PerAmount=100, PromotionUserType= 3 , UserYear=0 }
        };
        public async Task<List<PromotionEntity>> GetPromotionsByIdList(List<int> IdList)
        {
            return promotionList.FindAll(p => IdList.Contains(p.PromotionId));
        }
    }
}
