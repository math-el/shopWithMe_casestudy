﻿using maviTest.Application.Dto;
using maviTest.Application.Interfaces.Repository;
using maviTest.Domain.Entities;
using maviTest.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Persistence.Repositories
{
    internal class UserRepository : GenericRepository<UserEntity>, IUserRepository
    {

        public UserRepository(ApplicationDbContext dbContext) : base(dbContext)
        {


        }
        private static List<UserEntity> userList = new List<UserEntity>()
        {
            new UserEntity(){ Id=1, Name="Employee User", IsAffiliate=false, IsEmployee=true, UserActivationDate= DateTime.Now.AddYears(-1)},
            new UserEntity(){ Id=2, Name="Affiliate User", IsAffiliate=true, IsEmployee=false, UserActivationDate= DateTime.Now.AddYears(-1)},
            new UserEntity(){ Id=3, Name="Loyal User", IsAffiliate=false, IsEmployee=false, UserActivationDate= DateTime.Now.AddYears(-3)},
            new UserEntity(){ Id=4, Name="Loyal Employee User", IsAffiliate=false, IsEmployee=true, UserActivationDate= DateTime.Now.AddYears(-3)},
            new UserEntity(){ Id=5, Name="Loyal Affiliate User", IsAffiliate=true, IsEmployee=false, UserActivationDate= DateTime.Now.AddYears(-3)},
        };
        public async Task<UserEntity> GetById(int Id)
        {
            return userList.Where(u => u.Id == Id).FirstOrDefault();
        }
    }
}
