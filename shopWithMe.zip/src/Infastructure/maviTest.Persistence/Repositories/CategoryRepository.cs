﻿using maviTest.Application.Dto;
using maviTest.Application.Interfaces.Repository;
using maviTest.Domain.Entities;
using maviTest.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Persistence.Repositories
{
    internal class CategoryRepository : GenericRepository<CategoryEntity>, ICategoryRepository
    {

        public CategoryRepository(ApplicationDbContext dbContext) : base(dbContext)
        {


        }
        private static List<CategoryEntity> categoryViewList = new List<CategoryEntity>()
                {
                    new CategoryEntity { Id = 1, CategoryName = "Clothes" },
                    new CategoryEntity { Id = 2, CategoryName = "Cosmetic" },
                    new CategoryEntity { Id = 3, CategoryName = "Grocery" }
                };
        public async Task<List<CategoryEntity>> GetCategoriesByIdList(List<int> IdList)
        {
            return categoryViewList.FindAll(p => IdList.Contains(p.Id));
        }
    }
}
