﻿using maviTest.Application.Dto;
using maviTest.Application.Interfaces.Repository;
using maviTest.Domain.Entities;
using maviTest.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Persistence.Repositories
{
    internal class PromotionCategoryRepository : GenericRepository<PromotionCategoryEntity>, IPromotionCategoryRepository
    {

        public PromotionCategoryRepository(ApplicationDbContext dbContext) : base(dbContext)
        {


        }
        private static List<PromotionCategoryEntity> promotionCategoryList = new List<PromotionCategoryEntity>() {
        new PromotionCategoryEntity(){PromotionId=1, CategoryId=1},
        new PromotionCategoryEntity(){PromotionId=1, CategoryId=2},
        new PromotionCategoryEntity(){PromotionId=2, CategoryId=1},
        new PromotionCategoryEntity(){PromotionId=2, CategoryId=2},
        new PromotionCategoryEntity(){PromotionId=3, CategoryId=1},
        new PromotionCategoryEntity(){PromotionId=3, CategoryId=2},
        new PromotionCategoryEntity(){PromotionId=4, CategoryId=1},
        new PromotionCategoryEntity(){PromotionId=4, CategoryId=2},
        new PromotionCategoryEntity(){PromotionId=4, CategoryId=3}
        };
        public async Task<List<PromotionCategoryEntity>> GetPromotionCategoriesByIdList(List<int> IdList)
        {
            return promotionCategoryList.FindAll(p => IdList.Contains(p.CategoryId));
        }
    }
}
