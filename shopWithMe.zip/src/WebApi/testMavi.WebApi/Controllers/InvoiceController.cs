﻿using maviTest.Application.Dto;
using maviTest.Application.Enum;
using maviTest.Application.Exceptions;
using maviTest.Application.Features.Queries;
using maviTest.Application.Model;
using maviTest.Application.Wrappers;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace shopWithMe.WebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class InvoiceController : Controller
    {
        private readonly IMediator mediator;
        public InvoiceController(IMediator mediator)
        {
            this.mediator = mediator;
        }


        [HttpPost("")]
        public async Task<IActionResult> GetInvoiceAmount(ShoppingModel shoppingModel)
        {
            try
            {
                if (shoppingModel.UserId == 0)
                {
                    return BadRequest("User cannot be empty");
                }

                if (shoppingModel.ShoppingCardList.Any(s => s.ProductId == 0))
                {
                    return BadRequest("Product cannot be zero");
                }

                if (shoppingModel.ShoppingCardList.Any(s => s.Count == 0))
                {
                    return BadRequest("Count of a product cannot be zero");
                }
                var invoiceQuery = new GetInvoiceQuery() { shoppingModel = shoppingModel };

                ServiceResponse<double> invoiceResponse = await mediator.Send(invoiceQuery);


                return Ok(invoiceResponse.Value);
            }
            catch (BusinessException ex)
            {
                throw new BusinessException(ex.Message);
            }
        }
    }
}
