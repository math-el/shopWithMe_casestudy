﻿using maviTest.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Domain.Entities
{
    public class PriceEntity : BaseEntity
    {
        public int ProductId { get; set; }
        public double PriceAmount { get; set; }
        public DateTime BeginDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
