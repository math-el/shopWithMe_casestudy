﻿using maviTest.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Domain.Entities
{
    public class PromotionEntity : BaseEntity
    {
        public int PromotionId { get; set; }
        public int PromotionPriceType { get; set; }
        public double DiscountAmount { get; set; }
        public int PromotionUserType { get; set; }
        public int PromotionType { get; set; }
        public double PerAmount { get; set; }
        public int UserYear { get; set; }
    }
}
