﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Application.Mapping
{
    public class GeneralMapping : Profile
    {
        public GeneralMapping()
        {
            CreateMap<Domain.Entities.ProductEntity, Dto.ProductViewDto>().ReverseMap();
            CreateMap<Domain.Entities.CategoryEntity, Dto.CategoryViewDto>().ReverseMap();
            CreateMap<Domain.Entities.UserEntity, Dto.UserViewDto>().ReverseMap();
        }
    }
}
