﻿
namespace maviTest.Application.Model
{
    public class ShoppingModel
    {
        public int UserId { get; set; }
        public List<ShoppingCart> ShoppingCardList { get; set; }
    }
}
