﻿using AutoMapper;
using maviTest.Application.Dto;
using maviTest.Application.Enum;
using maviTest.Application.Exceptions;
using maviTest.Application.Interfaces.Repository;
using maviTest.Application.Model;
using maviTest.Application.Wrappers;
using maviTest.Domain.Entities;
using MediatR;

namespace maviTest.Application.Features.Queries
{
    public class GetInvoiceQuery : IRequest<ServiceResponse<double>>
    {
        public ShoppingModel shoppingModel { get; set; }

        public class GetInvoiceQueryHandler : IRequestHandler<GetInvoiceQuery, ServiceResponse<double>>
        {
            private readonly IMapper mapper;
            private readonly IUserRepository userRepository;
            private readonly IProductRepository productRepository;
            private readonly IPriceRepository priceRepository;
            private readonly IPromotionCategoryRepository promotionCategoryRepository;
            private readonly IPromotionRepository promotionRepository;
            public GetInvoiceQueryHandler(IUserRepository userRepository, IProductRepository productRepository, IPriceRepository priceRepository, IPromotionCategoryRepository promotionCategoryRepository, IPromotionRepository promotionRepository, IMapper mapper)
            {
                this.userRepository = userRepository;
                this.productRepository = productRepository;
                this.priceRepository = priceRepository;
                this.promotionCategoryRepository = promotionCategoryRepository;
                this.promotionRepository = promotionRepository;
                this.mapper = mapper;

            }
            public async Task<ServiceResponse<double>> Handle(GetInvoiceQuery request, CancellationToken cancellationToken)
            {

                var user = userRepository.GetById(request.shoppingModel.UserId);

                if (user.Result is null)
                {
                    throw new BusinessException("User cannot be found");
                }

                List<int> productIdList = request.shoppingModel.ShoppingCardList.Select(x => x.ProductId).ToList();

                var productList = productRepository.GetProductByIdList(productIdList);

                if (productList == null)
                {
                    throw new BusinessException("Product cannot be found");
                }
                var price = priceRepository.GetPricesByIdList(productIdList);

                List<int> categoryIdList = productList.Result.Select(x => x.CategoryId).ToList();

                var promotionCategory = promotionCategoryRepository.GetPromotionCategoriesByIdList(categoryIdList);

                var promotionIdList = promotionCategory.Result.Select(x => x.PromotionId).ToList();

                var promotions = promotionRepository.GetPromotionsByIdList(promotionIdList);

                List<PromotionEntity> userPromotions = new List<PromotionEntity>();

                if (user.Result.IsEmployee)
                {
                    userPromotions.AddRange(promotions.Result.Where(x => x.PromotionUserType == (int)PromotionUserType.Employee).ToList());
                }
                if (user.Result.IsAffiliate)
                {
                    userPromotions.AddRange(promotions.Result.Where(x => x.PromotionUserType == (int)PromotionUserType.Affiliate).ToList());
                }

                userPromotions.AddRange(promotions.Result.Where(x => x.PromotionUserType == (int)PromotionUserType.All && (DateTime.Now.Date - user.Result.UserActivationDate).TotalDays > (x.UserYear * 365)));

                PromotionEntity userPercentagePromotion = userPromotions.Where(x => x.PromotionPriceType == (int)PromotionPriceType.Percent).OrderByDescending(x => x.DiscountAmount).FirstOrDefault();

                double totalBillingAmount = price.Result.Sum(x => x.PriceAmount * request.shoppingModel.ShoppingCardList.Where(s => s.ProductId == x.ProductId).Select(s => s.Count).FirstOrDefault());
                double discountAmount = 0;
                if (userPercentagePromotion != null)
                {
                    List<int> percentagePromotionCategory = promotionCategory.Result.FindAll(x => x.PromotionId == userPercentagePromotion.PromotionId).Select(x => x.CategoryId).ToList();

                    List<int> percentageProductList = productList.Result.FindAll(x => percentagePromotionCategory.Contains(x.CategoryId)).Select(x => x.Id).ToList();

                    discountAmount = price.Result.FindAll(x => percentageProductList.Contains(x.ProductId)).Sum(x => ((x.PriceAmount * request.shoppingModel.ShoppingCardList.Where(s => s.ProductId == x.ProductId).Select(s => s.Count).FirstOrDefault()) * userPercentagePromotion.DiscountAmount) / 100);
                }

                double discountedBillingAmount = totalBillingAmount - discountAmount;

                userPromotions.FindAll(x => x.PromotionPriceType == (int)PromotionPriceType.Price).ForEach(userPromotion =>
                {
                    if (userPromotion.PromotionType == (int)PromotionType.TotalAmount)
                    {
                        discountedBillingAmount = discountedBillingAmount - userPromotion.DiscountAmount;
                    }
                    else
                    {
                        discountAmount = (int)Math.Floor(discountedBillingAmount / userPromotion.PerAmount) * userPromotion.DiscountAmount;
                        discountedBillingAmount = discountedBillingAmount - discountAmount;
                    }
                });

                return new ServiceResponse<double>(discountedBillingAmount);
            }
        }
    }
}
