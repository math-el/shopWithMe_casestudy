﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Application.Exceptions
{
    public class BusinessException : Exception
    {
        public BusinessException() : this("Business Exception occured")
        {

        }
        public BusinessException(string message) : base(message)
        {
            
        }
        public BusinessException(Exception ex) : this(ex.Message)
        {

        }
    }
}
