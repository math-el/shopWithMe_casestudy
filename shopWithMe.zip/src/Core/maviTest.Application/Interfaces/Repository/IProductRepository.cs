﻿using maviTest.Application.Dto;
using maviTest.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace maviTest.Application.Interfaces.Repository
{

    public interface IProductRepository : IGenericRepositoryAsync<ProductEntity>
    {
        public Task<List<ProductEntity>> GetProductByIdList(List<int> IdList);
    }
}
