﻿using maviTest.Application.Dto;
using maviTest.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace maviTest.Application.Interfaces.Repository
{

    public interface IUserRepository : IGenericRepositoryAsync<UserEntity>
    {
        public Task<UserEntity> GetById(int Id);
    }
}
