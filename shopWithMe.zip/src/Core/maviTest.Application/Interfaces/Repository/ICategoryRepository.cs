﻿using maviTest.Application.Dto;
using maviTest.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace maviTest.Application.Interfaces.Repository
{

    public interface ICategoryRepository : IGenericRepositoryAsync<CategoryEntity>
    {
        public Task<List<CategoryEntity>> GetCategoriesByIdList(List<int> IdList);
    }
}
