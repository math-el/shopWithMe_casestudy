﻿using maviTest.Application.Dto;
using maviTest.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace maviTest.Application.Interfaces.Repository
{

    public interface IPromotionCategoryRepository : IGenericRepositoryAsync<PromotionCategoryEntity>
    {
        public Task<List<PromotionCategoryEntity>> GetPromotionCategoriesByIdList(List<int> IdList);
    }
}
