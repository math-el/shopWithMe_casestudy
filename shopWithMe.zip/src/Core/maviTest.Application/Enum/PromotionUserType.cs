﻿
namespace maviTest.Application.Enum
{
    public enum PromotionUserType
    {
        Affiliate = 1,
        Employee = 2,
        All = 3
    }
}
