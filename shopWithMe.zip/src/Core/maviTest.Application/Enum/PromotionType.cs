﻿

namespace maviTest.Application.Enum
{
    public enum PromotionType
    {
        Default = 0,
        PerAmount = 1,
        TotalAmount = 2
    }
}
