﻿

namespace maviTest.Application.Enum
{
    public enum PromotionPriceType
    {
        Price = 1,
        Percent = 2
    }
}
