﻿using maviTest.Application.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Application.Dto
{
    public class PromotionViewDto
    {
        public int PromotionId { get; set; }
        public PromotionPriceType PromotionPriceType { get; set; }
        public double DiscountAmount { get; set; }
        public PromotionUserType PromotionUserType { get; set; }
        public PromotionType PromotionType { get; set; }
        public double PerAmount { get; set; }
        public int UserYear { get; set; }

    }
}
