﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Application.Dto
{
    public class CategoryViewDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
    }
}
