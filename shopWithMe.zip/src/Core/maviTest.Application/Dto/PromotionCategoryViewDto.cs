﻿using maviTest.Application.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maviTest.Application.Dto
{
    public class PromotionCategoryViewDto
    {
        public int PromotionId { get; set; }
        public int CategoryId { get; set; }

    }
}
